//
//  ContentViewModel.swift
//  RMSwiftUI
//
//  Created by Ken Torimaru on 10/16/20.
//

import Foundation
import UIKit
class ContentViewModel: ObservableObject {
    @Published var characters = [CharacterModel]()
    @Published var favorites: Set<CharacterModel> = Set<CharacterModel>()
    @Published var images = [String: UIImage?]()
    var favArray: [CharacterModel] {
        Array(favorites)
    }
    func getData() {
        NetworkManager.shared.fetchCharacters(page: nil) { result in
            switch result {
            case .success(let characters):
                DispatchQueue.main.async {
                    self.characters = characters
                }
                
                characters.forEach {
                    guard let name = $0.name else {
                        return
                        
                    }
                    print(name)
                }
            case .failure(let error):
                print(error.localizedDescription)
            
            }
        }

    }
    
}

