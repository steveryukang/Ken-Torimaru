//
//  ContentView.swift
//  RMSwiftUI
//
//
//  Copyright © 2020 com.adt.myadtmobileenterprise. All rights reserved.

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var viewModel: ContentViewModel
    @State var fetched: Bool = false
    var body: some View {
        if !fetched {
            Button(action: {
                viewModel.getData()
                fetched = true
            }, label: {
                Text("Fetch")
            })
        } else {
            VStack {
                HStack {
                    ForEach(viewModel.favArray, id: \.self) { fav in
                        Text(fav.name ?? "NA")
                    }
                }
                VStack {
                    ScrollView {
                        ForEach(viewModel.characters, id: \.self) { character in
                            CharacterBoxView(character: character)
                                .padding(4)
                        }
                    }.padding(0)
                }.padding(0)
            }
        }
    }
}

struct CharacterBoxView: View {
    var character: CharacterModel
    var body: some View {
        HStack {
//            Image(uiImage: )
            if let c = character {
                CharacterTextView(character: c)
            }
        }
    }
}
struct CharacterTextView: View {
    var character: CharacterModel
    var body: some View {
        VStack {
            if let text = character.species {
                Text(text)
            }
            if let text = character.gender {
                Text(text.rawValue)
            }
            if let text = character.origin {
                Text(text)
            }
            if let text = character.status {
                Text(text.rawValue)
            }
            if let text = character.name {
                Text(text)
            }

        }
    }
}
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
